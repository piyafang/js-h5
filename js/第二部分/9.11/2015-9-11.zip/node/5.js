//版权 北京智能社©, 保留所有权利

var str='e3423fsd43 343rer ter.rkj.d5456';

console.log(str.match(/\d+/g));