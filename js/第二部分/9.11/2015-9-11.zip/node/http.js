//版权 北京智能社©, 保留所有权利

//CMD规范
var http=require('http');

var server=http.createServer(function (){		//回调——
	//console.log('有人访问了');
});

server.listen(456);