//版权 北京智能社©, 保留所有权利

console.log('abc');