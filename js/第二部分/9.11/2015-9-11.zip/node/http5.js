//版权 北京智能社©, 保留所有权利

var http=require('http');
var fs=require('fs');

var server=http.createServer(function (request, response){
	fs.readFile('www'+request.url, function (err, data){
		if(err)
		{
			response.write('404');
		}
		else
		{
			response.write(data);
		}
		
		response.end();
	});
});

server.listen(456);















