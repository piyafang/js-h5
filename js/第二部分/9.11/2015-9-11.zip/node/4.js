//版权 北京智能社©, 保留所有权利

var arr=[12,5,8,9,3,97,6];

arr.sort(function (n1, n2){
	return n1-n2;
});

console.log(arr);