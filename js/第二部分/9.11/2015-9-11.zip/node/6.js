//版权 北京智能社©, 保留所有权利

function Person(name, age)
{
	this.name=name;
	this.age=age;
}

Person.prototype.showName=function ()
{
	console.log(this.name);
};
Person.prototype.showAge=function ()
{
	console.log(this.age);
};

var p=new Person('blue', 18);

p.showName();
p.showAge();












