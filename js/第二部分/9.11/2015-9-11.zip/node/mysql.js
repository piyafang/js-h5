//版权 北京智能社©, 保留所有权利

var mysql=require('mysql');

//1.连接 & 选择库
//createConnection(地址, 用户名, 密码)
var db=mysql.createConnection({host: '127.0.0.1', user: 'root', password: '', database: '20150908'});

//2.查询 & 接收
//query(sql语句, 回调)
db.query('SELECT * FROM user_table', function (err, data){
	if(err)
	{
		console.log('错了');
	}
	else
	{
		console.log(JSON.stringify(data));
	}
});

















