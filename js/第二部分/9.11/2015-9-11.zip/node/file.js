//版权 北京智能社©, 保留所有权利

var fs=require('fs');	//file system

//readFile(名字, 回调)
fs.readFile('aaa.txt', function (err, data){
	if(err)
	{
		console.log('读取失败');
	}
	else
	{
		console.log('成功：\n'+data);
	}
});