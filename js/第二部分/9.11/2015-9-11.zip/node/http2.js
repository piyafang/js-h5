//版权 北京智能社©, 保留所有权利

//CMD规范
var http=require('http');

var server=http.createServer(function (request, response){
	//request	请求		输入——请求信息
	//response	响应		输出——响应回去
	
	response.write('dr65tfd');
	response.end();			//没了
});

server.listen(456);















