//版权 北京智能社©, 保留所有权利

var a=12;
var b=5;

console.log(a+b);