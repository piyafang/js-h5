//版权 北京智能社©, 保留所有权利

var http=require('http');

var server=http.createServer(function (request, response){
	switch(request.url)
	{
		case '/a.html':
			response.write('dr65tfd');
			break;
		case '/b.html':
			response.write('bvvdvvsdf');
			break;
		case '/c.html':
			response.write('rter456456');
			break;
		default:
			response.write('\
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\
<html><head>\
<title>My 404 Not Found</title>\
</head><body>\
<h1>Not Found</h1>\
<p>The requested URL '+request.url+' was not found on this server.</p>\
<p>Additionally, a 404 Not Found\
error was encountered while trying to use an ErrorDocument to handle the request.</p>\
</body></html>\
');
	}
	
	response.end();			//没了
});

server.listen(456);















