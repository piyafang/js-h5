//版权 北京智能社©, 保留所有权利

//CMD规范
var http=require('http');

var server=http.createServer(function (request, response){
	console.log(request.url);
	
	response.write('dr65tfd');
	response.end();			//没了
});

server.listen(456);















