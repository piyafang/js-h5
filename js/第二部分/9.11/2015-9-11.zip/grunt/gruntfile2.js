module.exports=function (grunt){
	//1.
	grunt.loadNpmTasks('grunt-contrib-uglify');
	
	//2.
	grunt.initConfig({
		uglify: {
			aaa: {
				cwd: 'js/',
				src: '**/*.js',
				dest: 'build/',
				expand: true
			}
		}
	});
	
	//3.
	grunt.registerTask('default', ['uglify']);
};



















