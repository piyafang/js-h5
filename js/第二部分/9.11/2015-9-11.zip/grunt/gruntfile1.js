module.exports=function (grunt){
	//1.
	grunt.loadNpmTasks('grunt-contrib-uglify');
	
	//2.
	grunt.initConfig({
		uglify: {		//主任务名
			aaa: {		//子任务名
				src: 'js/drag.js',
				dest: 'build/drag.min.js'
			}
		}
	});
	
	//3.
	grunt.registerTask('default', ['uglify']);
};



















