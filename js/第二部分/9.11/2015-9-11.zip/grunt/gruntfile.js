module.exports=function (grunt){
	grunt.loadNpmTasks('grunt-contrib-htmlmin');
	
	grunt.initConfig({
		htmlmin: {
			bbb: {
				options: {
					removeComments: true,
					collapseWhitespace: true
				},
				files: {
					'build/弹性+摩擦2.html': 'html/弹性+摩擦2.html'
				}
			}
		}
	});
	
	grunt.registerTask('default', ['htmlmin']);
};



















