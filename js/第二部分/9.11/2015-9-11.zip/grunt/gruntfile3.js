module.exports=function (grunt){
	grunt.loadNpmTasks('grunt-contrib-cssmin');
	
	grunt.initConfig({
		cssmin:	{
			bbb: {
				cwd: 'css/',
				src: '**/*.css',
				dest: 'build/',
				expand: true
			}
		}
	});
	
	grunt.registerTask('default', ['cssmin']);
};



















